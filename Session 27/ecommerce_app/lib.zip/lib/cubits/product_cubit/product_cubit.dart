import 'package:ecommerce_app/cubits/product_cubit/product_cubit_states.dart';
import 'package:ecommerce_app/services/product_services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../models/product_model.dart';
// import '../../models/product_model.dart';

class ProductCubit extends Cubit<ProductCubitStates> {
  ProductCubit() : super(ProductsInitialState());

  getProducts() async {
    emit(ProductsLoadingState());
    try {
      List<ProductModel> products = await ProductServices().getAllProducts();
      emit(ProductsLoadedState(products: products));
    } catch (e) {
      emit(ProductFailurState(errMessage: e.toString()));
    }
  }

  addProduct({required ProductModel product}) async {
    emit(ProductsLoadingState());
    try {
      await ProductServices().createProduct(productModel: product);
      List<ProductModel> products = await ProductServices().getAllProducts();
      emit(ProductsLoadedState(products: products));
    } catch (e) {
      emit(ProductFailurState(errMessage: e.toString()));
    }
  }

  updateProduct({required ProductModel product, required int id}) async {
    emit(ProductsLoadingState());
    try {
      await ProductServices().updateProduct(productModel: product, id: id);
      List<ProductModel> products = await ProductServices().getAllProducts();
      emit(ProductsLoadedState(products: products));
    } catch (e) {
      emit(ProductFailurState(errMessage: e.toString()));
    }
  }

  deleteProduct({required int id}) async {
    emit(ProductsLoadingState());
    try {
      await ProductServices().deleteProduct(id: id);
      List<ProductModel> products = await ProductServices().getAllProducts();
      emit(ProductsLoadedState(products: products));
    } catch (e) {
      emit(ProductFailurState(errMessage: e.toString()));
    }
  }

  // getCubitFunProducts() async {
  //   emit(GetProductsLoadingState());
  //   try {
  //     List<ProductModel> products =
  //         await GetAllProductsServices().getAllProductus();
  //     emit(GetProductsSuccessState.ProductsSuccessState(products: products));
  //   } catch (e) {
  //     emit(GetProductsFailureState(errMessage: e.toString()));
  //   }
  // }
}
