import '../../models/product_model.dart';

class ProductCubitStates {}

class ProductsInitialState extends ProductCubitStates {}

class ProductsLoadingState extends ProductCubitStates {}

class ProductsLoadedState extends ProductCubitStates {
  final List<ProductModel> products;

  ProductsLoadedState({required this.products});
}

class ProductFailurState extends ProductCubitStates {
  final String errMessage;
  ProductFailurState({required this.errMessage});
}
