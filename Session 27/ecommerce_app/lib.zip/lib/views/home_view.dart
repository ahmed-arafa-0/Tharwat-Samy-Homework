import 'package:ecommerce_app/cubits/product_cubit/product_cubit_states.dart';
import 'package:ecommerce_app/views/add_product_view.dart';
import 'package:ecommerce_app/widgets/products_gridview.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../cubits/product_cubit/product_cubit.dart';

class HomeView extends StatelessWidget {
  static const String id = 'HomeView';
  const HomeView({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => ProductCubit()..getProducts(),
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          title: Text('E-Commerce'),
          backgroundColor: Colors.white,
          actions: [
            IconButton(
              onPressed: () {
                Navigator.of(context).pushNamed(AddProductView.id);
              },
              icon: Icon(Icons.add, color: Colors.black),
            ),
          ],
        ),
        body: BlocConsumer<ProductCubit, ProductCubitStates>(
          listener: (context, state) {
            if (state is ProductFailurState) {
              ScaffoldMessenger.of(
                context,
              ).showSnackBar(SnackBar(content: Text(state.errMessage)));
            }
          },
          builder: (context, state) {
            if (state is ProductsLoadedState) {
              return ProductsGridview(products: state.products);
            } else {
              return Center(child: CircularProgressIndicator());
            }
          },
        ),
      ),
    );
  }
}
