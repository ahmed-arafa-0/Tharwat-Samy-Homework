import 'package:ecommerce_app/cubits/product_cubit/product_cubit_states.dart';
import 'package:ecommerce_app/models/category_model.dart';
import 'package:ecommerce_app/models/product_model.dart';
import 'package:ecommerce_app/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../cubits/product_cubit/product_cubit.dart';

class AddProductView extends StatelessWidget {
  static const String id = 'AddProductView';

  const AddProductView({super.key});

  @override
  Widget build(BuildContext context) {
    String? title, slug, description, price, category;
    return BlocProvider(
      create: (context) => ProductCubit(),
      child: Scaffold(
        appBar: AppBar(title: Text('Add Product'), centerTitle: true),
        body: BlocConsumer<ProductCubit, ProductCubitStates>(
          listener: (context, state) {
            if (state is ProductFailurState) {
              ScaffoldMessenger.of(
                context,
              ).showSnackBar(SnackBar(content: Text(state.errMessage)));
            }
          },
          builder: (context, state) {
            return SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    CustomTextFormField(
                      text: "title",
                      onChanged: (value) {
                        title = value;
                      },
                    ),

                    CustomTextFormField(
                      text: "description",
                      onChanged: (value) {
                        description = value;
                      },
                    ),
                    CustomTextFormField(
                      text: "price",
                      textInputType: TextInputType.number,
                      onChanged: (value) {
                        price = value;
                      },
                    ),

                    ElevatedButton(
                      onPressed: () {
                        BlocProvider.of<ProductCubit>(context).addProduct(
                          product: ProductModel(
                            title: title ?? '',
                            slug: "",
                            description: description ?? "",
                            category: CategoryModel(
                              id: 1,
                              name: 'name',
                              slug: 'slug',
                              image: 'image',
                            ),
                            image: ["https://placehold.co/600x400"],
                            id: 0,
                            price: num.parse(price ?? '0'),
                          ),
                        );
                      },
                      child: Text('Add Product'),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
